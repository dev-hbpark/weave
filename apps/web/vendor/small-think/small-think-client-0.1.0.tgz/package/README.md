# @small-think/client

Browser-safe SDK to expose **your local tools** to a small-think **agent-server**
over a reverse-MCP WebSocket. You define tools; a remote LLM agent (running on the
server, holding the API key) reasons and calls your tools over the socket. Your
process plays the MCP-server role — "the client pretends to be an MCP server."

## Install

```bash
npm install @small-think/client
```

One package — it re-exports the tool contracts and `valibot` (`v`).

## Use

```ts
import { createToolClient, defineTool, v, type UntrustedContent } from "@small-think/client";

const echo = defineTool({
  name: "demo.echo",
  description:
    "Echo text back. Read-only, no side effects. Use to test the connection. Returns { echoed }.",
  input: v.object({ text: v.string() }),
  inputJsonSchema: {
    type: "object",
    properties: { text: { type: "string" } },
    required: ["text"],
    additionalProperties: false,
  },
  invoke: async ({ text }) => ({ echoed: text }),
});

const client = await createToolClient({
  url: "wss://agent.example.com",
  token: process.env.SMALL_THINK_TOKEN!,
  tools: [echo],
});

const result = await client.submit("Echo 'hello' back to me.");
console.log(result.finalText);
await client.close();
```

## Public interface (stable)

- **`defineTool(options)`** → a `ToolAdapter`. `input` (valibot) validates at runtime;
  `inputJsonSchema` is what the model sees. Set `destructive`/`mutating` to gate.
- **`createToolClient({ url, token, tools })`** → `{ submit(task), close() }`.
- **`connectToolClient({ url, token, registry })`** — lower-level (bring your own registry).
- Re-exports: `ToolError`, `isToolError`, `markUntrusted`, `toolId`, types
  (`ToolAdapter`, `ToolInvocationContext`, `UntrustedContent`, …), and `v` (valibot).

## Error codes

Tool failures throw `ToolError` with stable, namespaced `code`s
(`tool.dispatch.*`, `tool.invoke.*`, …). Branch on `error.code`, never message text.

## Security (read this)

The remote agent's LLM can be prompt-injected by upstream data, so **you own the
guardrails on your tools**: expose only an allow-list, mark destructive tools
(`destructive: true`) and gate them behind your own confirmation, and validate
inputs (the valibot `input` schema runs before `invoke`). Treat external data your
tools fetch as untrusted (`markUntrusted` / `UntrustedContent`). The connection is
authenticated by a shared `token` (v1; OAuth is the production target).

## Runtime

Browser and Node. The `ws` server library is **not** in this package's graph — it
dials using the platform `WebSocket`. (The Node WS *server* lives in
`@small-think/link/server`, used by the agent-server, not by clients.)

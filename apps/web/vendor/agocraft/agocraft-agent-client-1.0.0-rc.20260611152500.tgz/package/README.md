# @agocraft/agent-client

Opt-in package that exposes agocraft's editor commands to a [small-think](../../../small-think)
reverse-MCP agent server. agocraft core stays MCP-agnostic — this is the only place
small-think types meet agocraft.

It provides three things:

1. **Canonical command schemas** (`AGENT_COMMAND_SCHEMAS`) — JSON-Schema argument
   contracts for the core command kit, so an LLM agent calls each tool with the right shape.
2. **One-call kit registration** (`registerStandardCommands`).
3. **The connection itself** (`connectAgocraftAgent`).

## Command schemas — extend vs. retarget

There are two ways to derive a consumer's schema set from the canonical kit. Pick by
whether you keep the kit's command **names** or rename them.

### `mergeCommandSchemas(overrides, base?)` — add / override under the same names

Use when you add domain commands or tighten an existing one, keeping the canonical key:

```ts
import { mergeCommandSchemas, AGENT_COMMAND_SCHEMAS } from "@agocraft/agent-client";

const schemas = mergeCommandSchemas({
  "canvas-design.setTransform": { label: "Move/scale", inputSchema: /* … */ },
  "item.remove": { ...AGENT_COMMAND_SCHEMAS["item.remove"], destructive: false }, // override
});
```

### `retargetCommandSchemas(options, base?)` — re-expose the kit under YOUR namespace

Use when your registry names commands differently (e.g. `host.item.remove` instead of
`item.remove`) but wants the **identical** argument contract. This replaces hand-copying
specs — the contract is carried by import, so a later kit change propagates instead of
silently drifting.

```ts
import { retargetCommandSchemas, mergeCommandSchemas } from "@agocraft/agent-client";

// 1. Re-expose the absorbed kit commands under the host.* namespace.
const kit = retargetCommandSchemas({
  prefix: "host.",
  only: ["item.remove", "items.remove", "item.reparent", "frame.dissolve",
         "item.duplicate", "items.duplicate", "clipboard.copy", "clipboard.cut",
         "clipboard.paste", "children.reorder"],
  // optional: append a domain note or relabel, keyed by the PREFIXED name
  patch: {
    "host.item.remove": (spec) => ({ ...spec, label: "삭제" }),
  },
});

// 2. Layer host-specific commands over the retargeted kit (host-specific wins on collision).
export const HOST_COMMAND_SCHEMAS = mergeCommandSchemas(HOST_SPECIFIC, kit);
```

`options.only` defaults to every key in `base`. `retargetCommandSchemas` is **pure**
(returns a new record, never mutates `base`) and **throws loudly** when `only` names a
key absent from `base`, or when a `patch` key is not in the retargeted result — both are
build-time mistakes that must surface, not silently drop a tool from the agent's surface.

### What NOT to do

- Do **not** hand-copy entries out of `AGENT_COMMAND_SCHEMAS` into a consumer file — that
  is exactly the drift `retargetCommandSchemas` exists to remove.
- Do **not** prefix command keys by hand (string concatenation in the consumer).

See `CHANGELOG.md` for version history.

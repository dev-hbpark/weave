# @agocraft/input

Cross-cutting input layer for browser-class environments. Two cooperating sub-modules:

## bus — Input Event Normalization

PointerEvent / KeyboardEvent / WheelEvent → unified `NormalizedInputEvent` union.

```ts
import { createInputBus } from "@agocraft/input/bus";

const bus = createInputBus({ target: canvasEl, origin: "editor" });
const off = bus.subscribe((e) => {
  if (e.kind === "pointer" && e.modifiers.shift) {
    // constrain to axis
  }
});
bus.modifiers.subscribe((m) => {
  // realtime modifier state — emits even mid-drag, when Shift goes down DURING pointermove
});
// cleanup
off();
bus.dispose();
```

### Why a normalized payload

Mouse, pen, and touch arrive as `PointerEvent` in modern browsers — but the dimensions you care about (pointerType, pressure, modifiers, delta-since-last) take work to extract per event. The bus pre-computes them, attaches a stable `origin` tag, and emits a single discriminated union. Downstream code (selection, drag, drawing, hover) reads one shape regardless of device.

### Realtime modifier state

When the user starts a drag with `pointerdown`, then **presses Shift mid-drag** to constrain motion, the modifier change must propagate. The bus subscribes to `keydown` / `keyup` on `window` (capture phase) and republishes the new modifier set via the `bus.modifiers` signal. Consumers that need constrain-on-shift can subscribe to `bus.modifiers` alongside `bus.subscribe(pointerEvents)` and reconcile.

## hotkey — Context-Scoped Binding Registry

Subscribes to the bus's key events, dispatches actions by `scope` + `keys`. Exposes `getCandidates` for hint UIs (Notion-style Cmd-down → "what can I do with Cmd right now?").

```ts
import { createHotkeyRegistry } from "@agocraft/input/hotkey";

const hotkeys = createHotkeyRegistry({ bus });

const off = hotkeys.register({
  keys: "Cmd+Z",
  scope: "slide.editing",
  label: "Undo",
  action: () => undoCurrentSlide(),
});

hotkeys.activateScope("slide.s-7.title.editing");
// → "Cmd+Z" at "slide.editing" is active because "slide.editing" is NOT a prefix of "slide.s-7.title.editing".
// You'd typically activate "slide.editing" when entering edit mode, then the most-specific binding wins.

const candidates = hotkeys.getCandidates({ modifiers: { meta: true } });
// → [{ keys: "Cmd+Z", label: "Undo", scope: "slide.editing", ... }, ...]
```

### Scope tree

`global` is always active. Dot-separated paths nest. A binding is active when its scope equals `global`, equals the active scope, **or is a prefix** of the active scope (delimited by `.`). On collision, the longer (more specific) scope wins; tie-break is `priority` (higher wins).

```
global
  ↳ slide
    ↳ slide.s-7
      ↳ slide.s-7.title
        ↳ slide.s-7.title.editing
```

When the user focuses the title field of slide `s-7` in edit mode, the active scope is the deepest path, and bindings on every ancestor remain active. Activate the scope via `hotkeys.activateScope(path)` whenever focus moves.

### Conflicts

Two bindings at the same scope + same combo + same priority → developer warning. Resolve by raising one's `priority` or moving one to a different scope. The conflict callback is overridable via `onConflict`.

### Cross-platform `Mod` alias

`"Cmd"`, `"Command"`, `"Meta"`, `"Win"`, `"Super"`, and `"Mod"` all parse to the `meta` modifier. Use `"Mod"` when you mean "the OS command key, whichever it is on this platform" — the runtime maps macOS Cmd and Windows Win/Ctrl appropriately. (For now `Mod === meta`. macOS gets Cmd. Linux/Windows hosts that want Ctrl-as-Mod can install a translator at the bus boundary; planned for a future minor.)

## Sub-path exports + tree-shaking

- `@agocraft/input` — both modules
- `@agocraft/input/bus` — bus only (consumers that don't need hotkey)
- `@agocraft/input/hotkey` — hotkey only (assumes you pass a bus from somewhere)

Each entry is independently tree-shakeable. `package.json` declares `"sideEffects": false`.

## a11y

- The bus does **not** call `preventDefault` automatically. The hotkey registry calls it by default on matched bindings; opt out per binding with `preventDefault: false`.
- For ARIA `aria-keyshortcuts`, serialize the relevant `KeyCombo` via `serializeCombo`.

## Browser support

- Pointer Events — Baseline 2022.
- Wheel events — universal.
- Keyboard events — universal.
- `getCoalescedEvents()` (high-rate stylus) — not yet exposed; planned.

## Related

- WI-007, DR-014.
- Sister project consumer: weave's WI-004 Phase 3 (editing UX).
- HANDOFF-002 (`records/decision-handoffs/`) — the original request.

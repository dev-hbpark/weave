/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const clip_progress: (a: number, b: number, c: number, d: number) => number;
export const engine_version: () => [number, number];
export const frame_rect: (a: number, b: number, c: number, d: number, e: number) => [number, number];
export const sample_frame: (a: number, b: number, c: number, d: number) => number;
export const tint: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_start: () => void;

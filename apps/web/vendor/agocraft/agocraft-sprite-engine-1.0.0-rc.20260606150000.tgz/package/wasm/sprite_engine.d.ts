/* tslint:disable */
/* eslint-disable */

export function clip_progress(frame_count: number, fps: number, elapsed_ms: number, looping: boolean): number;

/**
 * Engine build identity — lets the JS facade assert it loaded the expected wasm.
 */
export function engine_version(): string;

export function frame_rect(cols: number, rows: number, sheet_w: number, sheet_h: number, index: number): Uint32Array;

export function sample_frame(frame_count: number, fps: number, elapsed_ms: number, looping: boolean): number;

export function tint(src: Uint8Array, r: number, g: number, b: number, strength: number): Uint8Array;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly clip_progress: (a: number, b: number, c: number, d: number) => number;
    readonly engine_version: () => [number, number];
    readonly frame_rect: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly sample_frame: (a: number, b: number, c: number, d: number) => number;
    readonly tint: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;

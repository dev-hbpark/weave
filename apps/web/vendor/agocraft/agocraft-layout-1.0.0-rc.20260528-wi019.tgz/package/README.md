# @agocraft/layout

Platform-tier layout capability for agocraft (WI-019). Ratio-native anchor
solver — given an `ItemFrame`-shaped parent rect and a list of children with
`LayoutChildPolicy`, computes new child rects deterministically.

v1 ships a single adapter: `absolute-constraints` (4 × 4 anchor cartesian,
T2 Modify Accept). Auto Layout (v2) and Grid (v3) plug in via the same
`LayoutAdapter` interface — no caller changes when new kinds arrive.

## Surface

```ts
import {
  type LayoutAdapter,
  type LayoutContext,
  type LayoutRegistry,
  createLayoutRegistry,
  createAbsoluteConstraintsAdapter,
  LAYOUT_ERROR_CODES,
  LayoutError,
} from "@agocraft/layout";

const registry = createLayoutRegistry();
registry.register(createAbsoluteConstraintsAdapter());

const adapter = registry.resolve("absolute-constraints");
const patches = adapter?.onParentResize(
  { parentOldRatio, parentNewRatio },
  children,
);
```

## Design

- Framework-free, ratio-only. No DOM / RAF / fetch / time.
- Determinism enforced by RULE.md + puritycheck gate.
- OS Rule 6: anchor formulas live in `HORIZONTAL_FORMULAS` /
  `VERTICAL_FORMULAS` lookup tables — no `switch (anchor)`.
- DR-013 factory pattern: `createX(deps)` returns a method record.

See `workspace/agocraft/records/work-items/WI-019-layout-management.md`,
`features/layout-management/ENGINEERING_PLAN.md` § 2.4-2.6.
